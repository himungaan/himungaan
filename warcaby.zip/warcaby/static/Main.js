let game
let net
let ui
window.onload = function () {
    net = new Net
    game = new Game
    ui = new Ui
}