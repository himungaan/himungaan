class Ui {
    constructor() {
        this.reset = document.getElementById("reset")
        this.login = document.getElementById("loguj")
        this.main()
    }
    //dodaje onclick do przycisków w main
    main = () => {
        this.reset.onclick = () => this.resetuj()
        this.login.onclick = () => this.loguj()
    }
    //reset nicku
    resetuj() {
        document.getElementById("nick").value = ""
        net.resetuj()
    }
    //logowanie -> do funkcji robiącej fetch
    loguj() {
        let nick = document.getElementById("nick").value
        net.check(nick)
    }
    //zmienia się treść statusu i znika formularz
    zalogowano = () => {
        document.getElementById("logowanie").style.display = "none"
        document.getElementById("status").innerHTML = "Witaj " + net.nick
        game.generujPionki()
    }
    oczekiwanie = () => {
        document.getElementById("wait").style.display = "block"
        var i = 0
        let f = async () => {
            //to zmień żeby wyglądało inaczej
            if (i == 0) {
                document.getElementById("wait").innerHTML = "Waiting."
            } if (i == 1) {
                document.getElementById("wait").innerHTML = "Waiting.."
            } if (i == 2) {
                document.getElementById("wait").innerHTML = "Waiting..."
                i = -1
            }
            i++
            let json = await net.secondUser()
            try {
                if (json.secondUser == true) {
                    clearInterval(w)
                    document.getElementById("wait").style.display = "none"
                    document.getElementById("status").innerHTML += "<br> Przeciwnik gra czerwonymi"
                    game.startRozgrywki()
                }
            } catch { }
        }
        let w = setInterval(f, 400)

    }
    kolor = (drugi) => {
        if (drugi == false) {
            game.user = "biale"
            document.getElementById("status").innerHTML += ", grasz białymi"
            game.twojRuch = true
        } else {
            game.user = "czerwone"
            document.getElementById("status").innerHTML += ", grasz czerwonymi"
            game.twojRuch = false
            game.startRozgrywki()
            document.getElementById("time").style.display = "block"
            var t = 30
            game.timer(t)
        }
    }
    genTab = () => {
        if (game.user = "biale"){
            let tab = document.getElementById("tab")
            tab.innerHTML = ""
            for (let a = 0; a < game.pionki.length; a++){
                let el = game.pionki[a]
                for (let b = 0; b < el.length; b++){
                    tab.innerHTML += el[b] + "  "
                }
                tab.innerHTML += "<br>"
            }
        }
    }
}