class Item extends THREE.Mesh {

    constructor() {
        super() // wywołanie konstruktora klasy z której dziedziczymy czyli z Mesha
        console.log(this)
    }
}
