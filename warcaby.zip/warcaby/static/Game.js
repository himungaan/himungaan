class Game {
    constructor() {
        //biale/czarne pola   
        this.szachownica = [
            [1, 0, 1, 0, 1, 0, 1, 0],
            [0, 1, 0, 1, 0, 1, 0, 1],
            [1, 0, 1, 0, 1, 0, 1, 0],
            [0, 1, 0, 1, 0, 1, 0, 1],
            [1, 0, 1, 0, 1, 0, 1, 0],
            [0, 1, 0, 1, 0, 1, 0, 1],
            [1, 0, 1, 0, 1, 0, 1, 0],
            [0, 1, 0, 1, 0, 1, 0, 1]
        ]
        //pozycje pionków
        this.pionki = [
            [0, 2, 0, 2, 0, 2, 0, 2],
            [2, 0, 2, 0, 2, 0, 2, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 0, 0, 0, 0, 0, 0, 0],
            [0, 1, 0, 1, 0, 1, 0, 1],
            [1, 0, 1, 0, 1, 0, 1, 0]
        ]
        //pozycja kamery X (zmienia sie przy drugim graczu)
        this.pos = -60
        this.scene = new THREE.Scene();
        this.camera = new THREE.PerspectiveCamera(45, 500 / 500, 0.1, 10000);
        this.camera.position.set(this.pos, 30, 0)
        this.camera.lookAt(this.scene.position);
        this.renderer = new THREE.WebGLRenderer();
        this.renderer.setClearColor(0xffffff);
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        document.getElementById("main").append(this.renderer.domElement);
        //zmień grafiki we wszystkich pionkach i polach
        //materiał czerwonego pionka
        this.pionek1material = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            map: new THREE.TextureLoader().load('https://i.imgur.com/Ncrkb8L.png'),
            transparent: true,
            opacity: 1,
            color: 0xff0000,
        })
        this.pionek1krolowka = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            map: new THREE.TextureLoader().load('https://i.imgur.com/Ncrkb8L.png'),
            transparent: true,
            opacity: 1,
            color: 0xff00ff,
        })
        //materiał białego pionka
        this.pionek2material = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            map: new THREE.TextureLoader().load('https://i.imgur.com/Ncrkb8L.png'),
            transparent: true,
            opacity: 1,
            color: 0xffffff,
        })
        this.pionek2krolowka = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            map: new THREE.TextureLoader().load('https://i.imgur.com/Ncrkb8L.png'),
            transparent: true,
            opacity: 1,
            color: 0xffccff,
        })
        this.pionek3material = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            map: new THREE.TextureLoader().load('https://i.imgur.com/Ncrkb8L.png'),
            transparent: true,
            opacity: 1,
            color: 0x00ff00,
        })
        //materiał czarnego pola
        this.pole1material = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            map: new THREE.TextureLoader().load('https://i.imgur.com/Ncrkb8L.png'),
            transparent: true,
            opacity: 1,
            color: 0x000000,
        })
        //materiał białego pola
        this.pole2material = new THREE.MeshBasicMaterial({
            side: THREE.DoubleSide,
            map: new THREE.TextureLoader().load('https://i.imgur.com/Ncrkb8L.png'),
            transparent: true,
            opacity: 1,
            color: 0xcccccc,
        })
        //geometry pola
        this.poleGeometry = new THREE.BoxGeometry(5, 1, 5)
        //geometry pionka
        this.pionekGeometry = new THREE.CylinderGeometry(2, 2, 1, 32);
        //generuje planszę
        this.start()
        this.render()

    }
    render = () => {
        requestAnimationFrame(this.render);
        this.renderer.render(this.scene, this.camera);
        console.log("render leci")
        TWEEN.update();
        window.onresize = this.resize()
    }
    //przy zmianie wielkości okna
    resize = function () {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }
    //generowanie planszy
    //trzeba zmienic na item
    start = () => {
        let x = -17.5
        for (let a = 0; a < this.szachownica.length; a++) {
            let z = -17.5
            for (let b = 0; b < this.szachownica.length; b++) {
                if (this.szachownica[a][b] == 0) {
                    let pole = new THREE.Mesh(this.poleGeometry, this.pole1material);
                    pole.kolorPola = "czarne"
                    pole.x = b
                    pole.z = a
                    pole.position.x += x
                    pole.position.z += z
                    this.scene.add(pole)
                } else {
                    let pole = new THREE.Mesh(this.poleGeometry, this.pole2material);
                    pole.kolorPola = "biale"
                    pole.position.x += x
                    pole.position.z += z
                    this.scene.add(pole)
                }
                z += 5
            }
            x += 5
        }
    }
    //generowanie pionków
    generujPionki = () => {
        let x = -17.5
        let y = 1
        this.tabPionki = []
        let nr = 0
        for (let a = 0; a < this.pionki.length; a++) {
            let z = -17.5
            for (let b = 0; b < this.pionki.length; b++) {
                if (this.pionki[a][b] == 1) {
                    //b - x w tablicy
                    //a - y w tablicy
                    //1 - kolor
                    let pionek = new Pionek(this.pionekGeometry, this.pionek1material, b, a, 1);
                    pionek.position.x += x
                    pionek.position.y += y
                    pionek.position.z += z
                    pionek.krolowka = false
                    this.tabPionki.push(pionek)
                    this.scene.add(pionek)
                } else if (this.pionki[a][b] == 2) {
                    //b - x w tablicy
                    //a - y w tablicy
                    //2 - kolor
                    let pionek = new Pionek(this.pionekGeometry, this.pionek2material, b, a, 2);
                    pionek.position.x += x
                    pionek.position.y += y
                    pionek.position.z += z
                    pionek.krolowka = false
                    this.tabPionki.push(pionek)
                    this.scene.add(pionek)
                } else {
                    //????
                }
                z += 5
            }
            x += 5
        }
    }
    //po dołączeniu dwóch graczy
    startRozgrywki = () => {
        this.raycaster = new THREE.Raycaster();
        this.mouseVector = new THREE.Vector2()
        this.klikniety = ""
        document.onmousedown = (e) => this.mouseDown(e)
    }
    //po kliknięciu
    mouseDown = (event) => {
        this.mouseVector.x = (event.clientX / window.innerWidth) * 2 - 1;
        this.mouseVector.y = -(event.clientY / window.innerHeight) * 2 + 1;
        this.raycaster.setFromCamera(this.mouseVector, this.camera);
        this.intersects = this.raycaster.intersectObjects(this.scene.children);
        if (this.intersects.length > 0) {
            //zaznacza pionki gracza
            if (this.twojRuch == true) {
                if (game.user == "biale" & this.intersects[0].object.kolor == 2) {
                    try { this.klikniety.material = this.pionek2material } catch { }
                    this.intersects[0].object.material = this.pionek3material
                    this.klikniety = this.intersects[0].object
                }
                if (game.user == "czerwone" & this.intersects[0].object.kolor == 1) {
                    try { this.klikniety.material = this.pionek1material } catch { }
                    this.intersects[0].object.material = this.pionek3material
                    this.klikniety = this.intersects[0].object
                }
                if (this.klikniety != "") {
                    //do wykonania ruchu
                    this.ruchGracza()
                }
            }

        }
    }
    ruchGracza = () => {
        //tylko czarne pola
        if (this.twojRuch == true) {
            if (this.intersects[0].object.kolorPola == "czarne") {
                //sprawdza czy pole jest wolne
                let check = this.check()
                if (check == true) {
                    //przesuwa pionek
                    new TWEEN.Tween(this.klikniety.position) // co
                        .to({ x: this.intersects[0].object.position.x, z: this.intersects[0].object.position.z }, 500) // do jakiej pozycji, w jakim czasie
                        .repeat(0) // liczba powtórzeń
                        .easing(TWEEN.Easing.Bounce.Out) // typ easingu (zmiana w czasie)
                        .start()
                    this.klikniety.position.x = this.intersects[0].object.position.x
                    this.klikniety.position.z = this.intersects[0].object.position.z
                    this.twojRuch = false
                    net.sendPionki()
                }
                //przywraca kolor
                if (game.user == "biale") {
                    this.klikniety.material = this.pionek2material
                } else if (game.user == "czerwone") {
                    this.klikniety.material = this.pionek1material
                }
                this.klikniety = ""
            }
        }
    }
    timer = (t) => {
        if (t >= 0 && this.twojRuch == false) {
            net.timeCheck()
            document.getElementById("time").innerHTML = t
            t--
            setTimeout(function () {
                game.timer(t)
            }, 1000)
        } else {
            document.getElementById("time").style.display = "none"
        }
    }
    check = () => {
        let krolowkaY = this.intersects[0].object.z - this.klikniety.y
        let krolowkaX = this.intersects[0].object.x - this.klikniety.x
        //sprawdza kolor i zmienia x i y obiektu
        if (this.pionki[this.intersects[0].object.z][this.intersects[0].object.x] == 0 & game.user == "biale") {
            if (this.intersects[0].object.z == (this.klikniety.y + 1)) {
                this.pionki[this.intersects[0].object.z][this.intersects[0].object.x] = 2
                this.pionki[this.klikniety.y][this.klikniety.x] = 0
                this.stareX = this.klikniety.x
                this.stareY = this.klikniety.y
                this.klikniety.y = this.intersects[0].object.z
                this.klikniety.x = this.intersects[0].object.x
                if (this.klikniety.y == 7) { this.klikniety.krolowka = true }
                document.getElementById("time").style.display = "block"
                this.twojRuch = false
                this.timer(30)
                return true
            } if (this.klikniety.krolowka == true) {
                if (krolowkaX / krolowkaY == 1 || krolowkaX / krolowkaY == -1) {
                    this.pionki[this.intersects[0].object.z][this.intersects[0].object.x] = 2
                    this.pionki[this.klikniety.y][this.klikniety.x] = 0
                    this.stareX = this.klikniety.x
                    this.stareY = this.klikniety.y
                    this.klikniety.y = this.intersects[0].object.z
                    this.klikniety.x = this.intersects[0].object.x
                    document.getElementById("time").style.display = "block"
                    this.twojRuch = false
                    this.timer(30)
                    return true
                }
            }
        } else if (this.pionki[this.intersects[0].object.z][this.intersects[0].object.x] == 0 & game.user == "czerwone") {
            if ((this.intersects[0].object.z + 1) == this.klikniety.y) {
                this.pionki[this.intersects[0].object.z][this.intersects[0].object.x] = 1
                this.pionki[this.klikniety.y][this.klikniety.x] = 0
                this.stareX = this.klikniety.x
                this.stareY = this.klikniety.y
                this.klikniety.y = this.intersects[0].object.z
                this.klikniety.x = this.intersects[0].object.x
                if (this.klikniety.y == 7) { this.klikniety.krolowka = true }
                document.getElementById("time").style.display = "block"
                this.twojRuch = false
                this.timer(30)
                //net.sendPionki()
                return true
            }
            if ((this.intersects[0].object.z - 1) == this.klikniety.y && this.klikniety.krolowka == true) {
                this.pionki[this.intersects[0].object.z][this.intersects[0].object.x] = 1
                this.pionki[this.klikniety.y][this.klikniety.x] = 0
                this.stareX = this.klikniety.x
                this.stareY = this.klikniety.y
                this.klikniety.y = this.intersects[0].object.z
                this.klikniety.x = this.intersects[0].object.x
                document.getElementById("time").style.display = "block"
                this.twojRuch = false
                this.timer(30)
                //net.sendPionki()
                return true
            }
        }
    }
    move = (stareX, stareY, noweX, noweY, nowePosX, nowePosY) => {
        //console.log(this.tabPionki)
        for (let l = 0; l < 16; l++) {
            if (this.tabPionki[l].x == stareX && this.tabPionki[l].y == stareY) {
                //console.log(this.tabPionki[l])
                game.pionki[stareY][stareX] = 0
                if (this.user == "biale") {
                    game.pionki[noweY][noweX] = 2
                } else {
                    game.pionki[noweY][noweX] = 1
                }
                //console.log(stareX, stareY, noweX, noweY, nowePosX, nowePosY)
                this.tabPionki[l].x = noweX
                this.tabPionki[l].y = noweY
                new TWEEN.Tween(this.tabPionki[l].position) // co
                    .to({ x: nowePosX, z: nowePosY }, 500) // do jakiej pozycji, w jakim czasie
                    .repeat(0) // liczba powtórzeń
                    .easing(TWEEN.Easing.Bounce.Out) // typ easingu (zmiana w czasie)
                    .start()
            }
        }
    }
}
