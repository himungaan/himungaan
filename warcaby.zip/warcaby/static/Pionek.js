class Pionek extends THREE.Mesh {
    constructor(geometry, material, x, y, kolor) {
        super(geometry, material) // wywołanie konstruktora klasy z której dziedziczymy czyli z Mesha
        this.x = x
        this.y = y
        this.kolor = kolor
    }
}

//const pionek = new Pionek()
